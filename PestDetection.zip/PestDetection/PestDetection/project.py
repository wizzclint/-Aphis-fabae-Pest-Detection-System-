import os
import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog, messagebox
from sklearn.model_selection import train_test_split
from keras.utils import to_categorical
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt

def load_images_from_folder(pest_folder):
    images = []
    labels = []

    for filename in os.listdir(pest_folder):
        img_path = os.path.join(pest_folder, filename)
        if os.path.isfile(img_path):
            img = cv2.imread(img_path)
            if img is not None:
                images.append(cv2.resize(img, (64, 64)))  # Resize images to 64x64
                labels.append(0)  # Assuming all images are pests (label=0)
            else:
                print(f"Warning: Unable to load image {img_path}")
    return np.array(images), np.array(labels)

# Update the path to your actual dataset location
dataset_path = 'C:/Users/Dell/Desktop/PestDetection-master/dataset/aphis_fabae'

X, y = load_images_from_folder(dataset_path)

# Normalize and preprocess data
X = X / 255.0  # Normalize pixel values to [0, 1]
y = to_categorical(y, num_classes=2)  # Convert labels to categorical (e.g., 0 -> [1, 0])

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define the model
def create_and_train_model(X_train, y_train, X_test, y_test):
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(64, 64, 3)),
        MaxPooling2D(pool_size=(2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Conv2D(128, (3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Flatten(),
        Dense(128, activation='relu'),
        Dropout(0.5),  # Adding dropout to reduce overfitting
        Dense(2, activation='softmax')  # 2 output classes: pest and non-pest
    ])

    model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])

    # Data augmentation
    datagen = ImageDataGenerator(
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        horizontal_flip=True
    )

    datagen.fit(X_train)

    # Train the model
    history = model.fit(datagen.flow(X_train, y_train, batch_size=32),
                        epochs=15,
                        validation_data=(X_test, y_test))  # Include validation data for monitoring

    # Plot training and validation accuracy and loss
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Training Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.legend()
    plt.title('Accuracy')

    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.legend()
    plt.title('Loss')
    plt.show()

    return model

# Train the model
trained_model = create_and_train_model(X_train, y_train, X_test, y_test)

# Function to preprocess a single image for prediction
def preprocess_image(image_path):
    try:
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError(f"Could not read image {image_path}.")
        img = cv2.resize(img, (64, 64))
        img = img / 255.0  # Normalize pixel values to [0, 1]
        return np.array(img).reshape(-1, 64, 64, 3)
    except Exception as e:
        print(f"Error in preprocessing image: {e}")
        return None

# Function to detect pest using the trained model
def detect_pest(image_path, model):
    processed_img = preprocess_image(image_path)
    if processed_img is None:
        return "Error processing the image."

    prediction = model.predict(processed_img)
    result = 'Aphis fabae Detected' if np.argmax(prediction) == 0 else 'No Pest Detected'

    # Display the input image
    try:
        img = cv2.imread(image_path)
        if img is not None:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  # Convert BGR to RGB
            plt.imshow(img)
            plt.title(result)
            plt.show()
        else:
            print(f"Warning: Could not display the image {image_path}.")
    except Exception as e:
        print(f"Error displaying image: {e}")

    return result

# Function to open file dialog and display result
def open_file():
    file_path = filedialog.askopenfilename()
    if file_path:
        result = detect_pest(file_path, trained_model)
        messagebox.showinfo("Detection Result", result)
    else:
        messagebox.showwarning("No File Selected", "Please select an image file to detect pests.")

# GUI Setup
root = tk.Tk()
root.title("Aphis fabae Pest Detection")
root.geometry("800x600")  # Set the size of the window

# Create and position GUI components
label = tk.Label(root, text="Aphis fabae Pest Detection System", font=("Arial", 24))
label.pack(pady=30)

open_button = tk.Button(root, text="Open Image", command=open_file, font=("Arial", 16), width=20, height=2)
open_button.pack(pady=20)

# Run the GUI main loop
root.mainloop()
