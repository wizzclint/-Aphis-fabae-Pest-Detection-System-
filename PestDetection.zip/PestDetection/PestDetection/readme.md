# 🐞 Aphis fabae Pest Detection System

A deep learning-based computer vision system for detecting **Aphis fabae** (black bean aphid) infestations using a Convolutional Neural Network (CNN) built with TensorFlow/Keras.

## 📌 Overview

This project automates agricultural pest detection by analyzing images and classifying them as either containing the Aphis fabae pest or not. It features an intuitive desktop GUI for easy image upload and real-time detection results.

## 🎯 Problem Statement

Aphis fabae is a destructive pest that damages:
- Beans
- Sugar beets
- Spinach
- Other legume crops

**Challenge:** Manual inspection is time-consuming, subjective, and often too late to prevent crop loss.

**Solution:** A CNN-based automated detection system that provides instant, accurate pest identification.

## 🛠️ Tech Stack

| Category | Technologies |
|----------|--------------|
| Deep Learning | TensorFlow, Keras |
| Language | Python 3.x |
| Image Processing | OpenCV |
| GUI Framework | Tkinter |
| Data Processing | NumPy, scikit-learn |
| Visualization | Matplotlib |

## 🧠 Model Architecture
